@extends('layouts.visitor')
@section('content')
<div class="container target " style="padding-top: 70px">
	<div class="row" id="top-buttons">
        <div class="col-lg-12">
           <h4><p class="text-center" style="color:red">Nội quy</p><h4>
           	<hr>
        </div>
    </div>
    <div class="row" id="top-buttons" style="border: 1px blue;">
        <div class="col-lg-8">
        	<div class="content" style="align-content: center;padding-left: 40%;">
			    1. Không cung cấp, trao đổi, truyền đưa thông tin xuyên tạc lịch sử, xúc phạm anh hùng dân tộc <br/>
			    2. Không đăng tải hình ảnh khiêu dâm, gợi dục <br/>
			    3. Không đăng tải hình ảnh, thông tin xúc phạm cá nhân hoặc tổ chức nào <br/>
			    4. Không bình luận vô văn hoá <br/>
			    5. Thành viên tự chịu trách nhiệm về nội dung mình đăng tải, mọi sai phạm sẽ bị khoá tài khoản truy cập vĩnh viễn <br/>
			</div>
        </div>
    </div>
</div>
@stop

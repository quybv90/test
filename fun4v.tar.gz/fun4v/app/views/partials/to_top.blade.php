<div class="text-right" id="back-top">
    <a class="back-to-top" id="backToTopBtn" href="/" title="Top"><img src="{{asset('images/back-to-top.png')}}"></a>
</div>
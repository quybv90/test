<?php

return array(
	"hot_videos" => "Video đang hot",
	"hot_photos" => "Ảnh đang hot",
	"view_all_posts1" => "Có tất cả ",
	"view_all_posts2" => " hình ảnh, Hiển thị tất cả",
	"times" => "Lượt",
	"post_times" => "Bài",
	"new_created" => "Bài của bạn đã được đăng, Hãy chờ đợi một chút để chúng tôi duyệt nhé",
	"approved_created" => "Bài của bạn đã được đăng",
	"create" => "Đăng bài",
	"may_you_also_like" => "Có thể bạn sẽ thích",
);




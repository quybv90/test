<aside id="sidebar">
	<div id="sticky-anchor"></div>
	<div id="last-widget">
	  <section class="widget clearfix">
	    <h4 class="widgettitle plugin-area-top plugin-text">Like <a href="https://www.facebook.com/fun4v">Fan page của Fun4v.com</a> bạn nhé !</h4>
	    <div class="fb-page" data-href="https://www.facebook.com/fun4v" data-width="300" data-hide-cover="false" data-show-facepile="true" data-show-posts="false"><div class="fb-xfbml-parse-ignore"><blockquote cite="https://www.facebook.com/fun4v"><a href="https://www.facebook.com/fun4v">Góc thư giãn.</a></blockquote></div></div>
	  </section>
	  <section class="widget clearfix">
	    <div class="fb-page"><img src="{{asset('images/quang-cao.jpg')}}" /></div>
	  </section>
	</div>
<!-- /.widget -->       
</aside>
<div class="facebook-share-box">
    <div class="share" style="margin-top:2em;width:90%">
        <div class="panel panel-default">
            <div class="panel-heading"><i class="fa fa-file"></i> Comment</div>
            <div class="panel-body">
                <div class="">
                    <textarea name="message" cols="40" rows="10" id="commentContent" class="form-control message" style="height: 62px; overflow: hidden;" placeholder="What's on your mind ?"></textarea> 
                </div>
            </div>
            <div class="panel-footer">
                <div class="row">
                    <div class="col-md-7">
                        <div class="form-group">
                            <div class="btn-group">
                                <button type="button" class="btn btn-default glyphicon glyphicon-picture"><i class="icon icon-picture"></i> Photo</button>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-5 text-right">
                        <div class="form-group">
                            <span>Press Enter to post <input type="checkbox" id="press_to_enter" name="pressEnter" value="true"checked></span>
                            <input type="button" id="postComment" value="Post" class="btn btn-primary">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

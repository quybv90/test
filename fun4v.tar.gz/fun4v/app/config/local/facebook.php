<?php
// app/config/facebook.php

// Facebook app Config 
return [
    'appId' => '1639562822925665',
    'secret' => '95f0a99070007a6f6954b7f0449bbefb',
    'scope' => ['public_profile', 'email'],
];

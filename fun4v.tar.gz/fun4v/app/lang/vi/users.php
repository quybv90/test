<?php

return array(
	"folow_me" => "Theo dõi",
	"send_message" => "Gửi tin nhắn",
	"profile" => "Thông tin người dùng",
	"last_update" => " Thay đổi gần đây",
	"created_at" => "Ngày tham gia",
	"user_name" => "Tên người dùng",
	"email" => "Email",
	"total_posts" => "Tổng số bài",
	"liked" => "Đã thích",
	"disliked" => "Không thích",
	"was_liked" => "Được thích",
	"user_hot_posts" => "Bài đăng HOT của ",
	"user_posts_title" => "Những bài đăng của ",
	"active" => "Hoạt động",
	"unapprove" => "Bài chưa duyện",
);

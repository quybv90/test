<?php

return [
    'SHOW_POST_PER_PAGE' => 10,
    'SHOW_COMMENT_PER_PAGE' => 10,
    ];

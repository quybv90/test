@extends('layouts.visitor')
@section('content')
<div class="container target " style="padding-top: 70px">
	<div class="row" id="top-buttons">
        <div class="col-lg-12">
           <h4><p class="" style="color:red">Điều khoản sử dụng gaixinh.fun4v</p><h4>
           	<hr>
        </div>
    </div>
    <div class="row" id="top-buttons" style="border: 1px blue;">
        <div class="col-lg-8">
        	<div class="content" >
		            &nbsp; &nbsp;Chúng tôi không chịu trách nhiệm với bất kỳ nội dung nào của thành viên đưa lên (Nội dung). <br />
		        Nội dung được đăng chỉ thể hiện quan điểm riêng của tác giả.

				Bạn phải đồng ý không sử dụng Dịch vụ để đăng, bàn luận hoặc liên kết đến bất kỳ Nội dung có liên quan đến chính trị, tôn giáo, đồi trụy, phân biệt vùng miền, phỉ báng, lăng mạ, hận thù, chia rẽ, đe dọa, xúc phạm, có chứa thông tin cá nhân của người khác, vi phạm bản quyền, phạm pháp, khuyến khích hành vi phạm pháp, hoặc vi phạm tất cả các điều luật khác.

				<br />Bạn phải trên 13 tuổi để sử dụng Dịch vụ này.

				<br />Chúng tôi có quyền xóa, sửa bất kỳ Nội dung nào đăng trên trang web với bất kỳ lý do mà không cần giải thích. 
				<br />Yêu cầu xóa bỏ hoặc sửa Nội dung sẽ thực hiện theo quyết định của chúng tôi. 
				<br />Chúng tôi giữ quyền hủy bỏ Dịch vụ (xóa tài khoản hoặc cấm) với Dịch vụ của chúng tôi bất kỳ lúc nào.

				<br />Bạn cho phép Chúng tôi quyền sử dụng, tái bản Nội dung của bạn với Dịch vụ vĩnh viễn, không giới hạn và không thể thu hồi. Bạn giữ quyền trên toàn Nội dung của mình.

				<br />Tất cả Nội dung bạn gửi lên hoặc tải lên có thể được kiểm duyệt bởi Ban quản trị. 
				<br />Không đăng bất kỳ Nội dung nào bạn cho là cá nhân hoặc tối mật.

				<br />Các điều khoản này có thể thay đổi bất kỳ lúc nào mà không cần báo trước.

				<br />Nếu bạn không đồng ý với các điều khoản này, xin hãy dừng việc đăng ký hoặc sử dụng Dịch vụ của chúng tôi. 
				<br />Nếu bạn muốn đóng tài khoản của mình, xin hãy dùng mục Liên hệ.
			</div>
        </div>
    </div>
</div>
@stop

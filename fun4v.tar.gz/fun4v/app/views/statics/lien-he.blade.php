@extends('layouts.visitor')
@section('content')
<div class="container target " style="padding-top: 70px">
	<div class="row" id="top-buttons">
        <div class="col-lg-12">
           <h4><p class="text-center" style="color:red">Liên hệ Email: <b class="text-info">contact.fun4v@gmail.com</b></p><h4>
           	<hr>
        </div>
    </div>
</div>
@stop
